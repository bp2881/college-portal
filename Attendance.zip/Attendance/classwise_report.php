<?php
// Session check (optional if needed for this page)
session_start();
$timeout_duration = 1800;
if (
  !isset($_SESSION['uid']) || !isset($_SESSION['logged_in']) || (time() - $_SESSION['login_time'] > $timeout_duration)
) {
  session_unset();
  session_destroy();
  header("Location: attendance_login.php?message=Session expired");
  exit();
}

// Refresh session time
$_SESSION['login_time'] = time();

$fdt = isset($_GET['from_date']) ? filter_var($_GET['from_date'], FILTER_SANITIZE_STRING) : '';
$tdt = isset($_GET['to_date']) ? filter_var($_GET['to_date'], FILTER_SANITIZE_STRING) : '';
$branch = isset($_GET['branch']) ? filter_var($_GET['branch'], FILTER_SANITIZE_STRING) : '';
$year = isset($_GET['year']) ? filter_var($_GET['year'], FILTER_SANITIZE_STRING) : '';
$section = isset($_GET['section']) ? filter_var($_GET['section'], FILTER_SANITIZE_STRING) : '';
$pythonScript = "C:\\xampp\\htdocs\\college-portal\\scripts\\classwise_attendance.py";
$command = "python $pythonScript $branch $fdt $tdt $year $section";
$output = shell_exec($command);

$jsonFile = "C:\\xampp\\htdocs\\college-portal\\class_attendance_data.json";
$data = [];
if (file_exists($jsonFile)) {
  $json = file_get_contents($jsonFile);
  $data = json_decode($json, true);
  if (json_last_error() !== JSON_ERROR_NONE) {
    $data = [];
    $error = "Error decoding JSON: " . json_last_error_msg();
  }
} else {
  $error = "JSON file not found.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Vignan Student Attendance Portal</title>
</head>

<body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f0f4f8;">
  <div
    style="text-align: center; background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
    <img src="./images/vignan_logo.png" alt="College Logo" width="80">
    <h1 style="color: #d62828; margin: 10px 0;">VIGNAN INSTITUTE OF TECHNOLOGY AND SCIENCE</h1>
    <p style="margin: 5px 0;">Near Ramoji Film City, Deshmukhi Village, Pochampally Mandal, Yadadri Bhuvanagiri Dist.
    </p>
    <p style="color: #023047; font-weight: bold; margin: 5px 0;">(Approved by AICTE, New Delhi, Affiliated to JNTUH,
      Hyderabad)</p>
    <h3 style="color: #d62828; margin: 5px 0;">AN AUTONOMOUS INSTITUTION</h3>
    <div
      style="position: absolute; top: 20px; right: 30px; border: 2px solid #888; padding: 10px; font-weight: bold; border-radius: 5px; background-color: #fefefe;">
      <p style="margin: 0;">Eamcet Code<br><span style="color: #d62828;">VGNT</span><br>Dist Code: <span
          style="color: #1d3557;">YBG</span></p>
    </div>
  </div>

  <div style="text-align: center; margin-top: 30px;">
    <h2 style="color: #264653;">Vignan Student Attendance Portal</h2>
    <h3>Class Attendance Report - AY 2024-25 I Sem.</h3>
    <p><strong>Branch:</strong> <?= htmlspecialchars($branch) ?>&nbsp;&nbsp;&nbsp;
      <strong>Year:</strong> <?= htmlspecialchars($year) ?>&nbsp;&nbsp;&nbsp;
      <strong>Sec:</strong> <?= htmlspecialchars($section) ?>
    </p>
    <p><strong>From:</strong> <?= htmlspecialchars($fdt) ?>&nbsp;&nbsp;&nbsp;
      <strong>To:</strong> <?= htmlspecialchars($tdt) ?>
    </p>
  </div>

  <div style="overflow-x: auto; margin-top: 30px;">
    <table border="1" cellspacing="0" cellpadding="5"
      style="width: 100%; border-collapse: collapse; background-color: white; font-size: 14px;">
      <thead style="background-color: #e63946; color: white;">
        <tr>
          <th rowspan="2">S.No.</th>
          <th rowspan="2">H.T No.</th>
          <th rowspan="2">Student Name</th>
          <?php
          // Automatically fetch unique subjects from the first student
          $subjects = [];
          if (!empty($data['students'][0]['subjects'])) {
            $subjects = array_keys($data['students'][0]['subjects']);
          }
          $colspan = count($subjects);
          ?>
          <th colspan="<?= $colspan ?>">Number of Hours Conducted</th>
          <th rowspan="2">Total</th>
          <th rowspan="2">Percentage (%)</th>
        </tr>
        <tr style="background-color: #f77f00; color: white;">
          <?php foreach ($subjects as $subject): ?>
            <th><?= htmlspecialchars($subject) ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>

      <tbody>
        <?php if (!empty($data['students'])): ?>
          <?php foreach ($data['students'] as $student): ?>
            <tr>
              <td><?= htmlspecialchars($student['sno']) ?></td>
              <td><?= htmlspecialchars($student['htno']) ?></td>
              <td><?= htmlspecialchars($student['name']) ?></td>
              <?php foreach ($subjects as $subject): ?>
                <td><?= htmlspecialchars($student['subjects'][$subject] ?? '-') ?></td>
              <?php endforeach; ?>
              <td><?= htmlspecialchars($student['total']) ?></td>
              <td><?= htmlspecialchars($student['percentage']) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="<?= 4 + $colspan ?>" style="text-align: center;">No attendance data available.</td>
          </tr>
        <?php endif; ?>
      </tbody>

    </table>
  </div>

  <div style="text-align: center; margin-top: 50px; font-size: 13px; color: #555;">
    <p>Generated by Vignan Attendance System</p>
  </div>
</body>

</html>